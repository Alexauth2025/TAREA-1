/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main1;

/*package main;*/
public class Main1 {
    public static void main(String[] args) {
        // 1. Imprimir "Hola, soy Alexandra Rodriguez"
        System.out.println("Hola, soy Alexandra Rodriguez");

        // 2. Operaciones aritméticas de dos números
        int num1 = 10, num2 = 5;
        System.out.println("Suma: " + (num1 + num2));
        System.out.println("Resta: " + (num1 - num2));
        System.out.println("Multiplicacion: " + (num1 * num2));
        System.out.println("Division: " + (num1 / num2));
        System.out.println("Modulo: " + (num1 % num2));

        // 3. Evaluación de expresiones
        int M = 6, T = 1, K = -10;
        System.out.println(M > T); // true
        System.out.println(T / K == -5); // true
        System.out.println((M + T == 7) || (M - T == 5)); // true

        // 4. Arreglo con 10 nombres
        String[] compañeros = {"Luis", "Maria", "Carlos", "Ana", "Pedro", "Sofia", "Juan", "Elena", "David", "Laura"};
        for (String nombre : compañeros) {
            System.out.println(nombre);
        }

        // 5. Arreglo multidimensional con datos personales
        String[][] compañerosInfo = {
            {"Compañeros","informacion"},
            {"Daniel", "Medina", "Electronica", "TEST"},
            {"Monica", "Jiz", "Computacion", "IMSA"},
            {"Carlos", "Gomez", "Mecatronica", "Siemens"},
            {"Laura", "Fernandez", "Industrial", "Coca-Cola"},
            {"Jose", "Ramirez", "Sistemas", "Google"}
        };

        for (String[] compañero : compañerosInfo) {
            System.out.println(String.join(" ", compañero));
        }

        // 6. Programa de calificaciones
        String[][] estudiantes = {
            {"Daniel", "65"},
            {"Monica", "89"},
            {"Pedro", "72"},
            {"Sofia", "50"},
            {"Luis", "95"}
        };

        for (String[] estudiante : estudiantes) {
            int nota = Integer.parseInt(estudiante[1]);
            String estado = (nota >= 60) ? "Aprobado" : "Reprobado";
            System.out.println(estudiante[0] + "\n" + nota + "\n" + estado + "\n");
        }

        // 7. Imprimir números pares del 2 al 100
        for (int i = 2; i <= 100; i += 2) {
            System.out.println(i);
        }
    }
}
